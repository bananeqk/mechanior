<?php
session_start();

if (!isset($_SESSION["user"]) || $_SESSION["user"]["uprawnienia_id"] < 2) {
    header("Location: ../login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="pl">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.5/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-SgOJa3DmI69IUzQ2PVdRZhwQ+dy64/BUtbMJw1MZ8t5HZApcHrRKUc4W0kG879m7" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css">
    <link rel="stylesheet" href="admin.css">
    <link
        href="https://fonts.googleapis.com/css2?family=Rubik:ital,wght@0,300..900;1,300..900&family=Syne:wght@400..800&display=swap"
        rel="stylesheet">
</head>

<body>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.5/dist/js/bootstrap.bundle.min.js" integrity="sha384-..."
        crossorigin="anonymous"></script>

    <aside>
        <div class="sidebar">
            <a href="../index.php">
                <img src="../zdjecia/sklep_logo.png" width="300px" class="p-3 mx-1 my-0">
            </a>
            <hr data-content="AND" class="hr-text text-black">
            <nav class="nav flex-column">
                <a href="#" class="nav-link" data-bs-toggle="collapse" data-bs-target="#submenu-0" aria-expanded="false"
                    aria-controls="submenu">
                    <span class="icon">
                        <i class="bi bi-grid"></i>
                    </span>
                    <span class="description fw-bold">Panel sterowania</span>
                </a>
                <div class="dashboard">
                    <div class="sub-menu collapse" id="submenu-0">
                        <a href="" class="nav-link">
                            <span class="icon">
                                <i class="bi bi-arrow-return-right"></i>
                            </span>
                            <span class="description">Statystyki</span>
                        </a>
                    </div>
                    <div class="sub-menu collapse" id="submenu-0">
                        <a href="accounts.php" class="nav-link">
                            <span class="icon">
                                <i class="bi bi-arrow-return-right"></i>
                            </span>
                            <span class="description">Administratorzy</span>
                        </a>
                    </div>
                </div>
                <a href="#" class="nav-link" data-bs-toggle="collapse" data-bs-target="#submenu-1" aria-expanded="false"
                    aria-controls="submenu">
                    <span class="icon">
                        <i class="bi bi-clipboard-check"></i>
                    </span>
                    <span class="description">Strona główna</span>
                </a>
                <div class="mainpage">
                    <div class="sub-menu collapse" id="submenu-1">
                        <a href="#" class="nav-link">
                            <span class="icon">
                                <i class="bi bi-arrow-return-right"></i>
                            </span>
                            <span class="description">Karuzela</span>
                        </a>
                    </div>
                    <div class="sub-menu collapse p-1" id="submenu-1">
                        <a href="#" class="nav-link">
                            <span class="icon">
                                <i class="bi bi-arrow-return-right"></i>
                            </span>
                            <span class="description">Wyróżnienia</span>
                        </a>
                    </div>
                    <div class="sub-menu collapse p-1" id="submenu-1">
                        <a href="#" class="nav-link">
                            <span class="icon">
                                <i class="bi bi-arrow-return-right"></i>
                            </span>
                            <span class="description">Produkty</span>
                        </a>
                    </div>
                    <div class="sub-menu collapse mb-3 p-1" id="submenu-1">
                        <a href="#" class="nav-link">
                            <span class="icon">
                                <i class="bi bi-arrow-return-right"></i>
                            </span>
                            <span class="description">Stopka</span>
                        </a>
                    </div>
                </div>
                <a href="#" class="nav-link" data-bs-toggle="collapse" data-bs-target="#submenu-2" aria-expanded="false"
                    aria-controls="submenu">
                    <span class="icon">
                        <i class="bi bi-clipboard-check"></i>
                    </span>
                    <span class="description">Katalog</span>
                </a>
                <a href="#" class="nav-link" data-bs-toggle="collapse" data-bs-target="#submenu-3" aria-expanded="false"
                    aria-controls="submenu">
                    <span class="icon">
                        <i class="bi bi-clipboard-check"></i>
                    </span>
                    <span class="description">O Firmie</span>
                </a>
                <a href="#" class="nav-link" data-bs-toggle="collapse" data-bs-target="#submenu-4" aria-expanded="false"
                    aria-controls="submenu">
                    <span class="icon">
                        <i class="bi bi-clipboard-check"></i>
                    </span>
                    <span class="description">Kontakt</span>
                </a>
            </nav>
        </div>
    </aside>
    <main class="main-content">
        <h2>Ddddddddd</h2>
    </main>



</body>

</html>